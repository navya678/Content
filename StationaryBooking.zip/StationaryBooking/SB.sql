create table T_XBBNHC9_StationaryBook (Emp_id int PRIMARY KEY, AIM_No varchar(10), Desk_No int, VOIP int, Material varchar(20), Quantity int )
delete from T_XBBNHC9_StationaryBook where Emp_id=456
drop table T_XBBNHC9_StationaryBook
select * from T_XBBNHC9_StationaryBook
insert into T_XBBNHC9_StationaryBook values(1245, 'A340A03', 56789, 19000, 'Marker-Green', 3)