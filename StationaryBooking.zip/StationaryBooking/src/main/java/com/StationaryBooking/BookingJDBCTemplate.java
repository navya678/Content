package com.StationaryBooking;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class BookingJDBCTemplate {
	private DataSource dataSource;
	   private static JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }

	
	   
	   public static List<BookingBean> getBookingDetails() {
		      String SQL = "select * from T_XBBNHC9_StationaryBook";
		      List<BookingBean> blist = new ArrayList<BookingBean>(); 
		      blist = jdbcTemplateObject.query(SQL, new BookingMapper());
		      return blist;
		   }
	   
	   public void insertBookingDetails(BookingBean b)
	   {
		   String SQL1 = "insert into T_XBBNHC9_StationaryBook values('"+b.getEmpid()+"','"+b.getAIMNo()+"','"+b.getDeskno()+"','"+b.getVoip()+"','"+b.getMaterial()+"','"+b.getQuantity()+"')";
		   jdbcTemplateObject.update(SQL1);
	   }

	
}
