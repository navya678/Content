package com.StationaryBooking;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class Data {

	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<BookingBean> output;
	
	
	public List<BookingBean>  getOutput() {
		return output;
	}
	public void setOutput(List<BookingBean> outputList) {
		this.output = outputList;
	}
}
