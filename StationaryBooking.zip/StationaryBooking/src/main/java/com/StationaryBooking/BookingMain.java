/*package com.StationaryBooking;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BookingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

	      BookingJDBCTemplate booking = 
	      (BookingJDBCTemplate)context.getBean("bookingJDBCTemplate");


	     
	      BookingBean b = BookingJDBCTemplate.getBookingDetails();
	      System.out.print("ID : " +b.getEmpid()  );
	      
	}

}
*/