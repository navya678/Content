package com.StationaryBooking;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BookingMapper implements RowMapper {

	public BookingBean mapRow(ResultSet rs, int rowno) throws SQLException {
		BookingBean booking = new BookingBean();
	      booking.setEmpid(rs.getInt(1));
	      booking.setAIMNo(rs.getString(2));
	      booking.setDeskno(rs.getInt(3));
	      booking.setVoip(rs.getInt(4));
	      booking.setMaterial(rs.getString(5));
	      booking.setQuantity(rs.getInt(6));
	      return booking;
		
	}

}
