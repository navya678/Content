package com.StationaryBooking;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@EnableSwagger2
@RestController
@Api(value = "booking", description = "Endpoint for user management")

/*@ApiResponses(value = {
    @ApiResponse(code = 200, message = "Successful retrieval of user detail", response = User.class),
    @ApiResponse(code = 404, message = "User with given username does not exist"),
    @ApiResponse(code = 500, message = "Internal server error")}
)*/

public class BookingController {
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@Autowired
	ErrorDetails errorDetails;
	@ApiOperation(value = "retrieves the details of all tests created", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of test details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "test with testid does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
@RequestMapping(value="/bookings", method = RequestMethod.GET)
public ResponseEntity<Response> viewBooking()
{
	BookingBean booking = new BookingBean();
	 List<BookingBean> li = new ArrayList<BookingBean>(); 
	try{
	
	li = BookingJDBCTemplate.getBookingDetails();
	//System.out.println("hi");
	//System.out.println(booking.getDeskno());
	saveMetaData(true,"Tests loaded","12345");
	saveData(null, li);
	saveResponse(data,metaData, null);
	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		errorDetails.setCode("00005");
		errorDetails.setDescription(e.getMessage());;
		saveMetaData(false,"Error Occured","12345");
		
		saveResponse(null,metaData,errorDetails);
		return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		//return response;
	}
	return new ResponseEntity<Response>(response, HttpStatus.OK);
}
@RequestMapping(value="/bookings", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
public void insertDetails(@RequestBody BookingBean bb)
{
	//BookingBean bb = new BookingBean();
	
	BookingJDBCTemplate b = new BookingJDBCTemplate();
	b.insertBookingDetails(bb);
	String a = bb.getAIMNo();
	System.out.println("hi");
}
private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}
private void saveData(ErrorDetails erroDet, List testObj) {
	response.setError(erroDet);
		data.setOutput(testObj);
	
}
private void saveMetaData(boolean success, String description, String responseId){
	
	
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}

}
