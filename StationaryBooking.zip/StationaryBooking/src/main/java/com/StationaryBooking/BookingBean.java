package com.StationaryBooking;

public class BookingBean {
private int empid;
private String AIMNo;
private int deskno;
private int voip;
private String material;
private int quantity;


public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getAIMNo() {
	return AIMNo;
}
public void setAIMNo(String aIMNo) {
	AIMNo = aIMNo;
}
public int getDeskno() {
	return deskno;
}
public void setDeskno(int deskno) {
	this.deskno = deskno;
}
public int getVoip() {
	return voip;
}
public void setVoip(int voip) {
	this.voip = voip;
}
public String getMaterial() {
	return material;
}
public void setMaterial(String material) {
	this.material = material;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}

}
